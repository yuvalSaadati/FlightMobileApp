package com.example.flightmobileapp

import androidx.lifecycle.LiveData

class AddressRepository(private val addressDao: AddressDao) {

    val allAddress: LiveData<List<Address>> = addressDao.getAllAddresses()

    suspend fun insert(address: Address) {
        addressDao.insert(address)
    }

    suspend fun deleteItem(address: Address) {
        addressDao.deleteItem(address)
    }

    suspend fun deleteAllButLast5() {
        addressDao.deleteAllButLast5()
    }
}