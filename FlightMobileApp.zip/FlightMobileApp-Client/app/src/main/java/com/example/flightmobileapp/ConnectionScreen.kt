package com.example.flightmobileapp

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import kotlinx.android.synthetic.main.activity_connection_screen.*
import java.time.OffsetDateTime

class ConnectionScreen : AppCompatActivity(),OnItemClickListener {

    private lateinit var addressViewModel: ViewModelAddress
    private val newAddressActivityRequestCode = 1
    private lateinit var adapter: AddressListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_connection_screen)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerview)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AddressListAdapter(this,this)
        recyclerView.adapter = adapter


        addressViewModel = ViewModelProvider(this).get(ViewModelAddress::class.java)
        addressViewModel.allAddress.observe(this, Observer { addresses ->
            // Update the cached copy of the words in the adapter.
            addresses?.let { adapter.setURLs(it) }
        })

        val extendedFab = findViewById<ExtendedFloatingActionButton>(R.id.URL_fab)
        extendedFab.setOnClickListener {
            val intent = Intent(this@ConnectionScreen, NewAddressActivity::class.java)
            startActivityForResult(intent, newAddressActivityRequestCode)
        }
        val connectFab = findViewById<ExtendedFloatingActionButton>(R.id.floatingActionButton)
        connectFab.setOnClickListener {
            //var address: CharSequence? = URL_fab.text;

                // Intents are objects of the android.content.Intent type. Your code can send them
                // to the Android system defining the components you are targeting.
                // Intent to start an activity called SecondActivity with the following code:

                var intent : Intent = Intent(this, MainActivity::class.java);

                // start the activity connect to the specified class
                startActivity(intent);
        }
    }

    override fun onItemClicked(address: Address) {
        //change text in Type URL button
        URL_fab.text = address.address;
        //delete and insert again item to list
        addressViewModel.deleteItem(address)
        val newAddress = Address(address.address)
        addressViewModel.insert(newAddress)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == newAddressActivityRequestCode && resultCode == Activity.RESULT_OK) {
            data?.getStringExtra(NewAddressActivity.EXTRA_REPLY)?.let {
                val address = Address(it)
                addressViewModel.insert(address)
                //addressViewModel.deleteAllButLast5()
            }
        } else {
            Toast.makeText(
                applicationContext,
                R.string.empty_not_saved,
                Toast.LENGTH_LONG).show()
        }
    }
}