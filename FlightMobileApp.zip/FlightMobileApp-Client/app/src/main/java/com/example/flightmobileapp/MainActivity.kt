package com.example.flightmobileapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView
import com.google.gson.GsonBuilder
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.ResponseBody
import retrofit2.Callback
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import android.graphics.BitmapFactory
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.MediaType
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Response
import java.io.IOException
import android.widget.ImageView
import io.github.controlwear.virtual.joystick.android.JoystickView
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

class MainActivity : AppCompatActivity() {

    var lastAileron: Double = 0.0
    var lastElevator: Double = 0.0
    var lastRudder: Double = 0.0
    var lastThrottle: Double = 0.0
    var minThrottle = 0
    var maxThrottle = 100
    var currentThrottle = 50
    var seekbarThrottle: SeekBar? = null
    var textViewThrottle: TextView? = null
    var minRudder = 0
    var maxRudder = 100
    var currentRudder = 50
    var seekbarRudder: SeekBar? = null
    var textViewRudder: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        seekbarThrottle = findViewById<SeekBar>(R.id.simpleSeekBarThrottle)
        textViewThrottle = findViewById<TextView>(R.id.textViewThrottle)
        seekbarRudder = findViewById<SeekBar>(R.id.simpleSeekBarRudder)
        textViewRudder = findViewById<TextView>(R.id.textViewRudder)

        seekbarRudder?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar, progress: Int,
                fromUser: Boolean
            ) {
                lastRudder =(progress/100).toDouble()
                //send to server
                post()
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }
        });

        seekbarThrottle?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar, progress: Int,
                fromUser: Boolean
            ) {
              lastThrottle = (progress/100).toDouble()
                //send to server
                post()
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }
        });

        var joystick =
            findViewById<io.github.controlwear.virtual.joystick.android.JoystickView>(R.id.joystickView)
        joystick.setOnMoveListener { angle: Int, strength: Int ->
            val length = strength
            val x = (length * cos(Math.toRadians(angle * 1.0))) / 100
            val y = (length * sin(Math.toRadians(angle * 1.0))) / 100
            if (changed(x, lastAileron) || changed(y, lastElevator)) {
                lastAileron = x
                lastElevator = y
                //send to server
                post()
            }
        }
        /////////////////////////////////////////////////////////////
        val gson = GsonBuilder()
            .setLenient()
            .create()
        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.2.2:57210")
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
        val api = retrofit.create(Api::class.java)
        CoroutineScope(Dispatchers.IO).launch {
            while (true) {
                delay(250)
                val body = api.getImg().enqueue(object : Callback<ResponseBody> {
                    override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                        println("bad")
                    }

                    override fun onResponse(
                        call: Call<ResponseBody>,
                        response: Response<ResponseBody>
                    ) {
                        println("good")
                        val I = response?.body()?.byteStream()
                        val B = BitmapFactory.decodeStream(I)
                        runOnUiThread {
                            imagePlanLayout.setImageBitmap(B)
                        }
                    }
                });
            }
        }
    }

    private fun changed(new: Double, old: Double): Boolean {
        if (new > old * 1.1) {
            return true
        }
        return false
    }

    fun post() {
        val json: String =
            "{\"aileron\": $lastAileron,\n \"rudder\": $lastRudder,\n \"elevator\": $lastElevator,\n \"throttle\": $lastThrottle\n}"
        val rb: RequestBody = RequestBody.create(MediaType.parse("application/json"), json)
        val gson = GsonBuilder()
            .setLenient()
            .create()
        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.2.2:57210")
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
        val api = retrofit.create(Api::class.java)
        val body = api.postData(rb).enqueue(object : Callback<ResponseBody> {
            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Toast.makeText(
                    applicationContext, t.message,
                    Toast.LENGTH_SHORT
                ).show()
                return
            }

            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                try {
                    Log.d("FlightMobileApp", response.body().toString())
                    println("make the update correctly")
                } catch (e: IOException) {
                    e.printStackTrace()
                    println("failed to make any post: catch")
                }
            }
        });
    }
}