package com.example.flightmobileapp

import androidx.room.*
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter


@Entity(tableName = "addresses_table")
data class Address(@PrimaryKey @ColumnInfo(name = "address") val address: String)

//@PrimaryKey @ColumnInfo(name = "address") val address: String