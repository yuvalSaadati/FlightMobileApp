package com.example.flightmobileapp

import androidx.lifecycle.LiveData
import androidx.room.*
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter

@Dao
interface AddressDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(address: Address)

    @Query("DELETE FROM addresses_table")
    suspend fun deleteAll()

    @Query("SELECT * FROM addresses_table LIMIT 5")
    fun getAllAddresses(): LiveData<List<Address>>

    @Delete
    suspend fun deleteItem(address: Address)

    @Query("DELETE FROM addresses_table where address NOT IN (SELECT address from addresses_table ORDER BY address DESC LIMIT 5)")
    suspend fun deleteAllButLast5()
}
//where address NOT IN (SELECT address from addresses_table ORDER BY address DESC LIMIT 5)