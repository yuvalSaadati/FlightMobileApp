package com.example.flightmobileapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AddressListAdapter(context: Context,
                         private val itemClickListener: OnItemClickListener
) :RecyclerView.Adapter<AddressListAdapter.AddressViewHolder>() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)
    private var addresses = emptyList<Address>() // Cached copy of url

    inner class AddressViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val addressItemView: TextView = itemView.findViewById(R.id.textView)

        fun bind(address: Address,clickListener: OnItemClickListener)
        {
            itemView.setOnClickListener {
                clickListener.onItemClicked(address)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AddressViewHolder {
        val itemView = inflater.inflate(R.layout.recyclerview_item, parent, false)
        return AddressViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: AddressViewHolder, position: Int) {
        val current = addresses[position]
        holder.addressItemView.text = current.address
        holder.bind(current,itemClickListener)
    }

    internal fun setURLs(addresses: List<Address>) {
        this.addresses = addresses
        notifyDataSetChanged()
    }

    override fun getItemCount() = addresses.size
}

interface OnItemClickListener{
    fun onItemClicked(address: Address)
}

    /*class AddressListAdapter internal constructor(
        context: Context
    ) : RecyclerView.Adapter<AddressListAdapter.AddressViewHolder>() {*/