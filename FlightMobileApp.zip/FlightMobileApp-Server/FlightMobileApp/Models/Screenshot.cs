﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightMobileApp.Models
{
    public class Screenshot
    {
        public string Ip { get; set; }
        public string Port { get; set; }
    }
}
